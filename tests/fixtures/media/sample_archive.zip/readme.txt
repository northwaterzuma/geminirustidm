RustCatch deterministic ZIP preview fixture.
